//Adil Zafar
// i have used depth-first searchapproach to explore possible paths, considering encounters with the soldiers and moves on the grid.
//using grid-based route-finding algorithm by depth-first search to handle obstacles and move constraint the goal is to find and display all possible routes from the castle while considering encounters with the soldiers
#include <iostream>
#include <vector>//used all the necessary header files like vector and cstdlib.ctime for random number genration
#include <cstdlib>
#include <ctime>

using namespace std;

const int GRID_SIZE = 9;

struct c {
    int x, y;
    c(int x = 0, int y = 0) : x(x), y(y) {}    // a structure to store the x,y c
};

vector<c> sldr;
c castle;
vector<vector<c>> routes;//storing all the postions of soldr and castle
vector<c> currentRoute;

bool isWithinBounds(const c& coord) {
    return coord.x >= 1 && coord.x <= GRID_SIZE && coord.y >= 1 && coord.y <= GRID_SIZE;
}

bool issoldier(const c& coord) {
    for (const auto& soldier : sldr) {
        if (soldier.x == coord.x && soldier.y == coord.y) {
            return true;
        }
    }                                                //returns true if a coordinate has asoldier
    return false;
}

void removesoldier(const c& coord) {
    for (auto it = sldr.begin(); it != sldr.end(); ++it) {
        if (it->x == coord.x && it->y == coord.y) {
            sldr.erase(it);
            return;
        }
    }                                                             //removing soldier
}

void exploreRoutes(c current, int moveDirection) {
    if (current.x == castle.x && current.y == castle.y && !sldr.empty()) {
        routes.push_back(currentRoute);
        return;
    }

    c next = current;
    if (moveDirection == 0) next.y++;      // Moving forward
    else if (moveDirection == 1) next.x++; // Moving left

    if (!isWithinBounds(next)) return;

    if (issoldier(next)) {
        currentRoute.push_back(next);
        c temp = next;
        removesoldier(next);
        exploreRoutes(next, 1); // Turn left after defeating
        sldr.push_back(temp);
        currentRoute.pop_back();
    } else {
        currentRoute.push_back(next);
        exploreRoutes(next, moveDirection);
        currentRoute.pop_back();
    }
}

void displayRoute(const vector<c>& route) {
    cout << "Start (" << castle.x << "," << castle.y << ")\n";
    for (size_t i = 1; i < route.size(); ++i) {
        if (issoldier(route[i])) {
            cout << "Defeat (" << route[i].x << "," << route[i].y << "). Turn Left\n";
        } else {
            cout << "Advance (" << route[i].x << "," << route[i].y << ")\n";
        }
    }
    cout << "Arrive (" << castle.x << "," << castle.y << ")\n";
}

int main() {
    srand(time(0));

    int numsldr;
    cout << "find_my_castle --sldr ";
    cin >> numsldr;

    for (int i = 1; i <= numsldr; ++i) {
        int x, y;
        cout << "Enter cordinates for soldier " << i << ": ";
        scanf("%d,%d", &x, &y);
        sldr.push_back(c(x, y));
    }

    cout << "Enter the cordinatess for your \"special\" castle: ";
    scanf("%d,%d", &castle.x, &castle.y);

    currentRoute.push_back(castle);
    exploreRoutes(castle, 0);

    cout << "Thanks. There are " << routes.size() << " unique routes to your 'special_castle'\n";
    for (size_t i = 0; i < routes.size(); ++i) {
        cout << "Route " << i + 1 << ":\n";
        cout << "=======\n";
        displayRoute(routes[i]);
        cout << endl;
    }

    return 0;
}
