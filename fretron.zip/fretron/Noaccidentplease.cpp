#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>

using namespace std;

struct Point {
    int x, y;
    Point(int _x = 0, int _y = 0) : x(_x), y(_y) {}//store coordinate on grid
};

struct Flight {
    vector<Point> points;
    char symbol;
};

void drawFlightPaths(const vector<Flight>& flights, int gridSize) {//list of flights into 2d grid
    vector<vector<char>> grid(gridSize, vector<char>(gridSize, '.'));

    for (const auto& flight : flights) {
        for (size_t i = 1; i < flight.points.size(); ++i) {
            const Point& start = flight.points[i-1];
            const Point& end = flight.points[i];
            
            int dx = end.x - start.x;
            int dy = end.y - start.y;
            int steps = max(abs(dx), abs(dy));
            
            for (int j = 0; j <= steps; ++j) {
                int x = start.x + j * dx / steps;
                int y = start.y + j * dy / steps;
                if (x >= 0 && x < gridSize && y >= 0 && y < gridSize) {
                    grid[y][x] = flight.symbol;
                }
            }
        }
    }

    for (int y = gridSize - 1; y >= 0; --y) {
        for (int x = 0; x < gridSize; ++x) {
            cout << grid[y][x] << ' ';
        }
        cout << endl;
    }
}

int main() {
    int n;
    cout << "Enter the number of flights: ";
    cin >> n;

    vector<Flight> flights(n);
    char symbol = 'A';
    int maxCoord = 0;

    for (int i = 0; i < n; ++i) {
        flights[i].symbol = symbol++;
        cout << "Enter coordinates for Flight " << i+1 << " (x1 y1 x2 y2 x3 y3): ";
        for (int j = 0; j < 3; ++j) {
            int x, y;
            cin >> x >> y;
            flights[i].points.emplace_back(x, y);
            maxCoord = max({maxCoord, x, y});
        }
    }

    drawFlightPaths(flights, maxCoord + 1);

    return 0;
}