//Adil Zafar
 //i have used greedy method by sorting apples and then allocating them based on the proportion of current weights compared to the shares.
#include <iostream>
#include <vector>
#include <algorithm>
#include <numeric>

using namespace std;

void give_apples(vector<int>& apples, int ramshare, int sham_share, int rahim_share) {//i tooka function which takes a vector of apple weights and the payment shares of Ram, Sham, and Rahim to store in avector
    int total = ramshare + sham_share + rahim_share;
    vector<int> ram, sham, rahim;
    int ram_weight = 0, sham_weight = 0, rahim_weight = 0;
    
    sort(apples.begin(), apples.end(), greater<int>());// i have sorted the apples in descending order by wt to prioritize allocating larger appls first which helps in  making it easier to get close to the target weights.
    
    for (int apple : apples) {//here i used a for loop to iterate through each apple and decides 
        double shamrtio = (double)sham_weight / sham_share;//which person should get the apple based on the proportion of wt already allocated to their share. 
        double ram_rtio = (double)ram_weight / ramshare;
        double rahimrtio = (double)rahim_weight / rahim_share;
        
        if (ram_rtio <= shamrtio && ram_rtio <= rahimrtio) {
            ram.push_back(apple);
            ram_weight += apple;
        } else if (shamrtio <= ram_rtio && shamrtio <= rahimrtio) {
            sham.push_back(apple);
            sham_weight += apple;
        } else {
            rahim.push_back(apple);
            rahim_weight += apple;
        }
    }
    
    cout << "Distribution Result:" << endl;//printing the apples aloocated to each person
    cout << "Ram: ";
    for (int apple : ram) cout << apple << " ";
    cout << endl;
    cout << "Sham: ";
    for (int apple : sham) cout << apple << " ";
    cout << endl;
    cout << "Rahim: ";
    for (int apple : rahim) cout << apple << " ";
    cout << endl;
}

int main() {
    vector<int> apples;
    int wt;
    
    cout << "Enter apple wt in gram (-1 to stop): ";
    while (cin >> wt && wt != -1) {
        apples.push_back(wt);
        cout << "Enter apple wt in gram (-1 to stop): ";
    }
    
    give_apples(apples, 50, 30, 20);
    
    return 0;
}